import type { PageMetadata, ClipMode } from "./types";
/**
 * 将相对 URL 解析为基于页面的绝对 URL
 */
export declare function resolveUrl(href: string, base: string): string;
/**
 * 清除 HTML 中无关的噪音标签（导航、侧边栏、广告、脚本、样式等）
 */
export declare function cleanHtml(html: string): string;
/**
 * 将 HTML 元素节点递归转换为精简 Markdown 文本
 */
export declare function elementToMarkdown(element: Element, baseUrl: string): string;
/**
 * 将任意 DOM Node 转换为 Markdown
 */
export declare function nodeToMarkdown(node: Node, baseUrl: string): string;
/**
 * 将 HTML 字符串转换为规范 Markdown
 */
export declare function htmlToMarkdown(html: string, baseUrl: string): string;
/**
 * 生成包含 Frontmatter 元数据的完整 Markdown 文件内容
 */
export declare function buildClipMarkdown(meta: PageMetadata, mode?: ClipMode, tags?: string[], notes?: string): string;
//# sourceMappingURL=parser.d.ts.map