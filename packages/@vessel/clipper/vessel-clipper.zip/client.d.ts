import type { ClipPayload, ClipResponse, VesselAppStatus } from "./types";
/**
 * 检查 Vessel 桌面端是否正在运行且已连接
 */
export declare function checkVesselStatus(): Promise<VesselAppStatus | null>;
/**
 * 将剪藏内容发送至 Vessel 桌面端保存到当前工作区
 */
export declare function saveClipToVessel(payload: ClipPayload): Promise<ClipResponse>;
/**
 * 降级选项：通过浏览器下载为本地 Markdown 文件
 */
export declare function downloadMarkdownFile(filename: string, content: string): void;
/**
 * 复制文本到剪贴板
 */
export declare function copyTextToClipboard(text: string): Promise<boolean>;
//# sourceMappingURL=client.d.ts.map