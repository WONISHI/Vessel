const z = "http://127.0.0.1:35678";
async function K() {
  try {
    const t = new AbortController(), r = setTimeout(() => t.abort(), 1200), n = await fetch(`${z}/api/status`, {
      method: "GET",
      signal: t.signal
    });
    return clearTimeout(r), n.ok ? await n.json() : null;
  } catch {
    return null;
  }
}
async function Q(t) {
  try {
    return await (await fetch(`${z}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (r) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(r)}`
    };
  }
}
function X(t, r) {
  const n = new Blob([r], { type: "text/markdown;charset=utf-8" }), e = URL.createObjectURL(n), i = document.createElement("a");
  i.href = e, i.download = t, document.body.appendChild(i), i.click(), document.body.removeChild(i), setTimeout(() => URL.revokeObjectURL(e), 1e3);
}
async function Y(t) {
  try {
    if (navigator.clipboard)
      return await navigator.clipboard.writeText(t), !0;
  } catch {
  }
  return !1;
}
function J(t, r) {
  try {
    return new URL(t, r).href;
  } catch {
    return t;
  }
}
function V(t) {
  return t.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, "").replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "").replace(/<svg\b[\s\S]*?<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function tt(t, r) {
  const n = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(n))
    return "";
  if (/^h[1-6]$/.test(n)) {
    const e = parseInt(n[1], 10), i = t.textContent?.trim() || "";
    return `

${"#".repeat(e)} ${i}

`;
  }
  if (n === "p") {
    const e = Array.from(t.childNodes).map((i) => b(i, r)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (["div", "section", "article", "figure", "header", "main", "aside", "details", "summary"].includes(n)) {
    const e = Array.from(t.childNodes).map((i) => b(i, r)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (n === "strong" || n === "b") {
    const e = t.textContent?.trim() || "";
    return e ? `**${e}**` : "";
  }
  if (n === "em" || n === "i") {
    const e = t.textContent?.trim() || "";
    return e ? `*${e}*` : "";
  }
  if (n === "del" || n === "s" || n === "strike") {
    const e = t.textContent?.trim() || "";
    return e ? `~~${e}~~` : "";
  }
  if (n === "a") {
    const e = t.getAttribute("href"), i = t.textContent?.trim() || e || "";
    if (!e) return i;
    const o = J(e, r);
    return `[${i}](${o})`;
  }
  if (n === "img") {
    const e = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!e) return "";
    const i = t.getAttribute("alt") || "image", o = J(e, r);
    return `

![${i}](${o})

`;
  }
  if (n === "pre") {
    const e = t.querySelector("code"), i = (e ? e.textContent : t.textContent) || "";
    let o = "";
    const a = (e?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return a && (o = a[1]), `

\`\`\`${o}
${i.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (n === "code")
    return `\`${t.textContent || ""}\``;
  if (n === "blockquote")
    return `

${Array.from(t.childNodes).map((i) => b(i, r)).join("").trim().split(`
`).map((i) => `> ${i}`).join(`
`)}

`;
  if (n === "ul")
    return `

${Array.from(t.children).filter((i) => i.tagName.toLowerCase() === "li").map((i) => `- ${Array.from(i.childNodes).map((d) => b(d, r)).join("").trim()}`).join(`
`)}

`;
  if (n === "ol")
    return `

${Array.from(t.children).filter((i) => i.tagName.toLowerCase() === "li").map((i, o) => {
      const d = Array.from(i.childNodes).map((a) => b(a, r)).join("").trim();
      return `${o + 1}. ${d}`;
    }).join(`
`)}

`;
  if (n === "table") {
    const e = Array.from(t.querySelectorAll("tr"));
    if (!e.length) return "";
    let i = `

`;
    return e.forEach((o, d) => {
      const a = Array.from(o.querySelectorAll("th, td")).map((T) => T.textContent?.trim().replace(/\|/g, "\\|") || "");
      a.length && (i += `| ${a.join(" | ")} |
`, d === 0 && (i += `| ${a.map(() => "---").join(" | ")} |
`));
    }), i + `
`;
  }
  return n === "hr" ? `

---

` : n === "br" ? `
` : Array.from(t.childNodes).map((e) => b(e, r)).join("");
}
function b(t, r) {
  return t.nodeType === 3 ? t.textContent || "" : t.nodeType === 1 ? tt(t, r) : "";
}
function D(t, r) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const e = new DOMParser().parseFromString(V(t), "text/html");
    return Array.from(e.body.childNodes).map((o) => b(o, r)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return V(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (n, e) => `

> ${e.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (n, e, i) => `

${"#".repeat(Number(e))} ${i.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function et(t, r = "article", n = [], e = "", i) {
  const o = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), d = [
    "---",
    `title: ${JSON.stringify(t.title || "未命名网页")}`,
    `url: ${JSON.stringify(t.url || "")}`,
    `clipped_at: ${JSON.stringify(o)}`,
    t.author ? `author: ${JSON.stringify(t.author)}` : null,
    t.siteName ? `site_name: ${JSON.stringify(t.siteName)}` : null,
    n.length ? `tags:
${n.map((c) => `  - ${JSON.stringify(c)}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((c) => c !== null).join(`
`), a = [`# ${t.title || "未命名网页"}`, "", `> 原文链接: [${t.url}](${t.url})`, t.author ? `> 作者: ${t.author}` : null, `> 剪藏时间: ${o.slice(0, 19).replace("T", " ")}`, ""].filter((c) => c !== null).join(`
`), T = e.trim() ? `
### 📝 我的笔记与标注

${e.trim()}

---
` : "";
  let p = "";
  if (r === "bookmark")
    p = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (r === "selection")
    p = `
### 摘录内容

${t.selectedHtml ? D(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let c = t.articleHtml ? D(t.articleHtml, t.url) : "";
    c.trim() || (c = t.articleText ? t.articleText : t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), p = `
${c}
`;
  }
  if (i !== void 0) {
    const c = {
      title: t.title || "未命名网页",
      url: t.url,
      author: t.author || "",
      site: t.siteName || "",
      description: t.description || "",
      date: o.slice(0, 10),
      content: p.trim(),
      notes: e.trim(),
      tags: n.join(", ")
    };
    return `${d}
${i.replace(/\{\{\s*(\w+)\s*\}\}/g, (k, l) => c[l] ?? k)}
`;
  }
  return `${d}
${a}${T}${p}`;
}
let s = {
  title: "网页剪藏",
  url: "",
  timestamp: (/* @__PURE__ */ new Date()).toISOString()
}, I = "article", H = !1, h = null, O = "default", S = !1;
const g = document.getElementById("clip-template"), C = document.getElementById("template-body"), j = document.getElementById("clip-author"), R = document.getElementById("clip-site"), nt = document.getElementById("clip-source"), rt = `# {{title}}

> 来源：[{{site}}]({{url}}) · {{date}}

{{content}}

## 我的笔记

{{notes}}`, it = `# {{title}}

[原文]({{url}}) · {{author}} · {{date}}

{{content}}

## 阅读笔记

{{notes}}`;
let G = !1;
async function F(t) {
  try {
    const r = typeof chrome < "u" ? chrome.storage?.local : void 0;
    if (t === "read") {
      const n = r ? (await r.get("clipperPreferences")).clipperPreferences : JSON.parse(localStorage.getItem("clipperPreferences") || "null");
      n && typeof n == "object" && (typeof n.folder == "string" && (M.value = n.folder), typeof n.tags == "string" && (N.value = n.tags), ["default", "quote", "custom"].includes(n.template) && (g.value = n.template), typeof n.body == "string" && (C.value = n.body));
    } else {
      const n = { folder: M?.value, tags: N?.value, template: g.value, body: C.value };
      r ? await r.set({ clipperPreferences: n }) : localStorage.setItem("clipperPreferences", JSON.stringify(n));
    }
  } catch {
  }
}
function Z() {
  document.getElementById("template-settings").hidden = g.value !== "custom";
}
const E = document.getElementById("clip-title"), M = document.getElementById("clip-folder"), N = document.getElementById("clip-tags"), U = document.getElementById("clip-notes"), m = document.getElementById("preview-content"), L = document.getElementById("toggle-preview-btn"), $ = document.getElementById("connection-status"), x = $?.querySelector(".text"), A = document.getElementById("message-bar"), v = document.getElementById("save-btn"), q = document.getElementById("download-btn"), P = document.getElementById("copy-btn"), W = document.querySelectorAll(".tab-btn");
function w(t, r = "success") {
  A && (A.textContent = t, A.className = `message-bar ${r}`, setTimeout(() => {
    A && (A.className = "message-bar");
  }, 4e3));
}
function f() {
  const t = (N?.value || "").split(/[,，\s]+/).map((i) => i.trim()).filter(Boolean), r = U?.value || "", n = et(
    {
      ...s,
      title: E?.value || s.title,
      author: j.value,
      siteName: R.value
    },
    I,
    t,
    r,
    g.value === "custom" ? C.value : g.value === "quote" ? rt : void 0
  );
  document.getElementById("edit-state").hidden = h === null;
  const e = h ?? n;
  return m && (m.value = e), document.getElementById("content-count").textContent = String(e.length), G && F("write"), e;
}
function _(t) {
  if (t === "selection" && !s.selectedText?.trim() && !s.selectedHtml?.trim()) {
    w("请先在网页中选择需要摘录的内容，再打开剪藏。", "error");
    return;
  }
  t !== I && h !== null && !window.confirm("切换模式将重新生成正文，是否继续？") || t !== I && (h = null, I = t, W.forEach((r) => {
    r.dataset.mode === t ? r.classList.add("active") : r.classList.remove("active");
  }), f());
}
W.forEach((t) => {
  t.addEventListener("click", () => {
    const r = t.dataset.mode;
    r && _(r);
  });
});
C.value = it;
m?.addEventListener("input", () => {
  h = m.value, document.getElementById("edit-state").hidden = !1, document.getElementById("content-count").textContent = String(m.value.length);
});
document.getElementById("reset-content")?.addEventListener("click", () => {
  h !== null && !window.confirm("重新生成将覆盖手动修改，是否继续？") || (h = null, f());
});
g.addEventListener("change", () => {
  if (h !== null && !window.confirm("应用模板将覆盖手动修改，是否继续？")) {
    g.value = O;
    return;
  }
  O = g.value, Z(), h = null, f();
});
for (const t of [j, R, C, M]) t?.addEventListener("input", f);
E?.addEventListener("input", f);
N?.addEventListener("input", f);
U?.addEventListener("input", f);
L?.addEventListener("click", () => {
  if (!m || !L) return;
  m.classList.contains("hidden") ? (m.classList.remove("hidden"), L.classList.add("open")) : (m.classList.add("hidden"), L.classList.remove("open"));
});
P?.addEventListener("click", async () => {
  const t = f();
  await Y(t) ? w("已复制 Markdown 内容至剪贴板", "success") : w("复制失败", "error");
});
q?.addEventListener("click", () => {
  const t = f(), n = (E?.value || s.title || "clip").replace(/[\\/:*?"<>|]/g, "-").trim();
  X(`${n}.md`, t), w("已开始下载 Markdown 文件", "success");
});
v?.addEventListener("click", async () => {
  if (!v || !S) return;
  const t = f(), r = (N?.value || "").split(/[,，\s]+/).map((n) => n.trim()).filter(Boolean);
  v.disabled = !0, v.textContent = "保存中...";
  try {
    const n = await Q({
      title: E?.value || s.title,
      url: s.url,
      markdown: t,
      tags: r,
      folder: M?.value || "Clippings",
      description: s.description,
      author: j.value,
      mode: I
    });
    if (n.ok && n.success)
      w(`✅ 保存成功: ${n.relativePath || n.filename || ""}`, "success");
    else {
      const e = n.message || n.error || "保存失败，请检查桌面端状态";
      w(`❌ ${e}`, "error");
    }
  } catch (n) {
    w(`保存失败: ${String(n)}`, "error");
  } finally {
    v.disabled = !1, v.textContent = "保存到 Vessel";
  }
});
async function ot() {
  let t = null;
  try {
    if (new URLSearchParams(location.search).get("vesselHost") !== "1" && !("vesselPageBridge" in window)) throw new Error("Use the active browser tab");
    const r = await fetch("http://127.0.0.1:35678/api/active-page", { signal: AbortSignal.timeout(2e3) });
    if (r.ok) {
      const n = await r.json(), e = n.data || n;
      e && (e.url || e.title) && (t = {
        title: e.title || "未命名网页",
        url: e.url || "",
        description: e.description || "",
        author: e.author || "",
        siteName: e.siteName || "",
        favicon: e.favicon || "",
        articleHtml: e.articleHtml || "",
        articleText: e.articleText || "",
        selectedText: e.selectedText || "",
        selectedHtml: e.selectedHtml || "",
        timestamp: e.timestamp || (/* @__PURE__ */ new Date()).toISOString()
      });
    }
  } catch {
  }
  if (!t || !t.articleHtml && !t.articleText && !t.selectedText)
    try {
      if (typeof chrome < "u" && chrome.tabs?.query) {
        const n = (await chrome.tabs.query({ active: !0, currentWindow: !0 }).catch(() => []))[0];
        if (n && n.id && n.url && /^https?:\/\//i.test(n.url)) {
          try {
            const e = await chrome.tabs.sendMessage(n.id, { type: "GET_PAGE_DATA" }).catch(() => null);
            e && (e.articleHtml || e.articleText || e.selectedText || e.url) && (t = e);
          } catch {
          }
          if (!t && chrome.scripting?.executeScript)
            try {
              const e = await chrome.scripting.executeScript({
                target: { tabId: n.id },
                /** Performs the func operation. */
                func: () => {
                  const i = window.getSelection(), o = i ? i.toString().trim() : "";
                  let d = "";
                  if (i && i.rangeCount > 0 && !i.isCollapsed) {
                    const l = document.createElement("div");
                    l.appendChild(i.getRangeAt(0).cloneContents()), d = l.innerHTML;
                  }
                  function a(l) {
                    ["script", "style", "noscript", "iframe", "svg", "nav", "header", "footer", "aside", ".sidebar", ".comments", ".ad"].forEach((y) => {
                      l.querySelectorAll(y).forEach((B) => B.remove());
                    });
                  }
                  const T = [
                    "#js_content",
                    ".Post-RichText",
                    ".RichContent-inner",
                    "#content_views",
                    ".article_content",
                    ".article-viewer",
                    ".markdown-body",
                    ".article-holder",
                    ".article-content",
                    "article",
                    "main",
                    "[role='main']",
                    ".post-content",
                    ".article-content",
                    ".entry-content",
                    "#article-root",
                    "#content",
                    ".article",
                    ".post_body",
                    ".post-body"
                  ];
                  let p = "", c = "";
                  for (const l of T) {
                    const u = document.querySelector(l);
                    if (u && (u.innerText || u.textContent || "").trim().length > 20) {
                      const y = u.cloneNode(!0);
                      a(y), p = y.innerHTML, c = (y.innerText || "").trim();
                      break;
                    }
                  }
                  if (!p) {
                    const l = document.body || document.documentElement;
                    if (l) {
                      const u = l.cloneNode(!0);
                      a(u), p = u.innerHTML, c = (u.innerText || "").trim();
                    }
                  }
                  const k = (l) => {
                    for (const u of l) {
                      const y = document.querySelector(`meta[name='${u}'], meta[property='${u}']`);
                      if (y) {
                        const B = y.getAttribute("content");
                        if (B) return B.trim();
                      }
                    }
                    return "";
                  };
                  return {
                    title: document.title || "未命名网页",
                    url: window.location.href,
                    description: k(["description", "og:description", "twitter:description"]),
                    author: k(["author", "article:author", "twitter:creator"]),
                    siteName: k(["og:site_name", "application-name"]) || window.location.hostname,
                    selectedText: o,
                    selectedHtml: d,
                    articleHtml: p,
                    articleText: c,
                    timestamp: (/* @__PURE__ */ new Date()).toISOString()
                  };
                }
              });
              e && e[0]?.result && (t = e[0].result);
            } catch (e) {
              console.warn("executeScript fallback error:", e);
            }
        }
      }
    } catch (r) {
      console.warn("Chrome tab query error:", r);
    }
  t && (s = t, j.value = s.author || "", R.value = s.siteName || "", nt.value = s.url, E && s.title && (E.value = s.title), s.selectedText && s.selectedText.trim() ? _("selection") : _("article")), S = !!t?.url, S || w("未能读取当前网页，请刷新网页后重新打开剪藏。", "error"), v && (v.disabled = !S), P && (P.disabled = !S), q && (q.disabled = !S), f();
}
async function ct() {
  await F("read"), O = g.value, G = !0, Z(), f();
  const t = ot();
  try {
    const r = await K();
    if (r && r.ok) {
      H = !0, $ && ($.className = "status-badge connected");
      const n = r.workspace?.name ? `已连接: ${r.workspace.name}` : "已连接 Vessel";
      x && (x.textContent = n);
    } else
      H = !1, $ && ($.className = "status-badge disconnected"), x && (x.textContent = "未连接桌面端");
  } catch (r) {
    console.error("Vessel check error:", r), H = !1, $ && ($.className = "status-badge disconnected"), x && (x.textContent = "未连接桌面端");
  }
  await t;
}
ct();
