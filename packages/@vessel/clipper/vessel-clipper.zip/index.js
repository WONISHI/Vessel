const g = "http://127.0.0.1:35678";
async function h() {
  try {
    const t = new AbortController(), i = setTimeout(() => t.abort(), 1200), n = await fetch(`${g}/api/status`, {
      method: "GET",
      signal: t.signal
    });
    return clearTimeout(i), n.ok ? await n.json() : null;
  } catch {
    return null;
  }
}
async function m(t) {
  try {
    return await (await fetch(`${g}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (i) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(i)}`
    };
  }
}
function y(t, i) {
  const n = new Blob([i], { type: "text/markdown;charset=utf-8" }), r = URL.createObjectURL(n), e = document.createElement("a");
  e.href = r, e.download = t, document.body.appendChild(e), e.click(), document.body.removeChild(e), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
async function b(t) {
  try {
    if (navigator.clipboard)
      return await navigator.clipboard.writeText(t), !0;
  } catch {
  }
  return !1;
}
function d(t, i) {
  try {
    return new URL(t, i).href;
  } catch {
    return t;
  }
}
function p(t) {
  return t.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, "").replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "").replace(/<svg\b[\s\S]*?<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function $(t, i) {
  const n = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(n))
    return "";
  if (/^h[1-6]$/.test(n)) {
    const r = parseInt(n[1], 10), e = t.textContent?.trim() || "";
    return `

${"#".repeat(r)} ${e}

`;
  }
  if (n === "p") {
    const r = Array.from(t.childNodes).map((e) => l(e, i)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (["div", "section", "article", "figure", "header", "main", "aside", "details", "summary"].includes(n)) {
    const r = Array.from(t.childNodes).map((e) => l(e, i)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (n === "strong" || n === "b") {
    const r = t.textContent?.trim() || "";
    return r ? `**${r}**` : "";
  }
  if (n === "em" || n === "i") {
    const r = t.textContent?.trim() || "";
    return r ? `*${r}*` : "";
  }
  if (n === "del" || n === "s" || n === "strike") {
    const r = t.textContent?.trim() || "";
    return r ? `~~${r}~~` : "";
  }
  if (n === "a") {
    const r = t.getAttribute("href"), e = t.textContent?.trim() || r || "";
    if (!r) return e;
    const o = d(r, i);
    return `[${e}](${o})`;
  }
  if (n === "img") {
    const r = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!r) return "";
    const e = t.getAttribute("alt") || "image", o = d(r, i);
    return `

![${e}](${o})

`;
  }
  if (n === "pre") {
    const r = t.querySelector("code"), e = (r ? r.textContent : t.textContent) || "";
    let o = "";
    const c = (r?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return c && (o = c[1]), `

\`\`\`${o}
${e.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (n === "code")
    return `\`${t.textContent || ""}\``;
  if (n === "blockquote")
    return `

${Array.from(t.childNodes).map((e) => l(e, i)).join("").trim().split(`
`).map((e) => `> ${e}`).join(`
`)}

`;
  if (n === "ul")
    return `

${Array.from(t.children).filter((e) => e.tagName.toLowerCase() === "li").map((e) => `- ${Array.from(e.childNodes).map((s) => l(s, i)).join("").trim()}`).join(`
`)}

`;
  if (n === "ol")
    return `

${Array.from(t.children).filter((e) => e.tagName.toLowerCase() === "li").map((e, o) => {
      const s = Array.from(e.childNodes).map((c) => l(c, i)).join("").trim();
      return `${o + 1}. ${s}`;
    }).join(`
`)}

`;
  if (n === "table") {
    const r = Array.from(t.querySelectorAll("tr"));
    if (!r.length) return "";
    let e = `

`;
    return r.forEach((o, s) => {
      const c = Array.from(o.querySelectorAll("th, td")).map((u) => u.textContent?.trim().replace(/\|/g, "\\|") || "");
      c.length && (e += `| ${c.join(" | ")} |
`, s === 0 && (e += `| ${c.map(() => "---").join(" | ")} |
`));
    }), e + `
`;
  }
  return n === "hr" ? `

---

` : n === "br" ? `
` : Array.from(t.childNodes).map((r) => l(r, i)).join("");
}
function l(t, i) {
  return t.nodeType === 3 ? t.textContent || "" : t.nodeType === 1 ? $(t, i) : "";
}
function f(t, i) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const r = new DOMParser().parseFromString(p(t), "text/html");
    return Array.from(r.body.childNodes).map((o) => l(o, i)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return p(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (n, r) => `

> ${r.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (n, r, e) => `

${"#".repeat(Number(r))} ${e.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function x(t, i = "article", n = [], r = "") {
  const e = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), o = [
    "---",
    `title: "${(t.title || "未命名网页").replace(/"/g, '\\"')}"`,
    `url: "${t.url || ""}"`,
    `clipped_at: "${e}"`,
    t.author ? `author: "${t.author.replace(/"/g, '\\"')}"` : null,
    t.siteName ? `site_name: "${t.siteName.replace(/"/g, '\\"')}"` : null,
    n.length ? `tags:
${n.map((a) => `  - ${a}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((a) => a !== null).join(`
`), s = [`# ${t.title || "未命名网页"}`, "", `> 原文链接: [${t.url}](${t.url})`, t.author ? `> 作者: ${t.author}` : null, `> 剪藏时间: ${e.slice(0, 19).replace("T", " ")}`, ""].filter((a) => a !== null).join(`
`), c = r.trim() ? `
### 📝 我的笔记与标注

${r.trim()}

---
` : "";
  let u = "";
  if (i === "bookmark")
    u = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (i === "selection")
    u = `
### 摘录内容

${t.selectedHtml ? f(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let a = t.articleHtml ? f(t.articleHtml, t.url) : "";
    a.trim() || (a = t.articleText ? t.articleText : t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), u = `
${a}
`;
  }
  return `${o}
${s}${c}${u}`;
}
export {
  x as buildClipMarkdown,
  h as checkVesselStatus,
  p as cleanHtml,
  b as copyTextToClipboard,
  y as downloadMarkdownFile,
  $ as elementToMarkdown,
  f as htmlToMarkdown,
  l as nodeToMarkdown,
  d as resolveUrl,
  m as saveClipToVessel
};
