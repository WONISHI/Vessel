const $ = "http://127.0.0.1:35678";
async function b() {
  try {
    const t = new AbortController(), i = setTimeout(() => t.abort(), 1200), n = await fetch(`${$}/api/status`, {
      method: "GET",
      signal: t.signal
    });
    return clearTimeout(i), n.ok ? await n.json() : null;
  } catch {
    return null;
  }
}
async function S(t) {
  try {
    return await (await fetch(`${$}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (i) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(i)}`
    };
  }
}
function x(t, i) {
  const n = new Blob([i], { type: "text/markdown;charset=utf-8" }), r = URL.createObjectURL(n), e = document.createElement("a");
  e.href = r, e.download = t, document.body.appendChild(e), e.click(), document.body.removeChild(e), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
async function A(t) {
  try {
    if (navigator.clipboard)
      return await navigator.clipboard.writeText(t), !0;
  } catch {
  }
  return !1;
}
function p(t, i) {
  try {
    return new URL(t, i).href;
  } catch {
    return t;
  }
}
function f(t) {
  return t.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, "").replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "").replace(/<svg\b[\s\S]*?<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function m(t, i) {
  const n = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(n))
    return "";
  if (/^h[1-6]$/.test(n)) {
    const r = parseInt(n[1], 10), e = t.textContent?.trim() || "";
    return `

${"#".repeat(r)} ${e}

`;
  }
  if (n === "p") {
    const r = Array.from(t.childNodes).map((e) => l(e, i)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (["div", "section", "article", "figure", "header", "main", "aside", "details", "summary"].includes(n)) {
    const r = Array.from(t.childNodes).map((e) => l(e, i)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (n === "strong" || n === "b") {
    const r = t.textContent?.trim() || "";
    return r ? `**${r}**` : "";
  }
  if (n === "em" || n === "i") {
    const r = t.textContent?.trim() || "";
    return r ? `*${r}*` : "";
  }
  if (n === "del" || n === "s" || n === "strike") {
    const r = t.textContent?.trim() || "";
    return r ? `~~${r}~~` : "";
  }
  if (n === "a") {
    const r = t.getAttribute("href"), e = t.textContent?.trim() || r || "";
    if (!r) return e;
    const o = p(r, i);
    return `[${e}](${o})`;
  }
  if (n === "img") {
    const r = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!r) return "";
    const e = t.getAttribute("alt") || "image", o = p(r, i);
    return `

![${e}](${o})

`;
  }
  if (n === "pre") {
    const r = t.querySelector("code"), e = (r ? r.textContent : t.textContent) || "";
    let o = "";
    const s = (r?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return s && (o = s[1]), `

\`\`\`${o}
${e.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (n === "code")
    return `\`${t.textContent || ""}\``;
  if (n === "blockquote")
    return `

${Array.from(t.childNodes).map((e) => l(e, i)).join("").trim().split(`
`).map((e) => `> ${e}`).join(`
`)}

`;
  if (n === "ul")
    return `

${Array.from(t.children).filter((e) => e.tagName.toLowerCase() === "li").map((e) => `- ${Array.from(e.childNodes).map((a) => l(a, i)).join("").trim()}`).join(`
`)}

`;
  if (n === "ol")
    return `

${Array.from(t.children).filter((e) => e.tagName.toLowerCase() === "li").map((e, o) => {
      const a = Array.from(e.childNodes).map((s) => l(s, i)).join("").trim();
      return `${o + 1}. ${a}`;
    }).join(`
`)}

`;
  if (n === "table") {
    const r = Array.from(t.querySelectorAll("tr"));
    if (!r.length) return "";
    let e = `

`;
    return r.forEach((o, a) => {
      const s = Array.from(o.querySelectorAll("th, td")).map((d) => d.textContent?.trim().replace(/\|/g, "\\|") || "");
      s.length && (e += `| ${s.join(" | ")} |
`, a === 0 && (e += `| ${s.map(() => "---").join(" | ")} |
`));
    }), e + `
`;
  }
  return n === "hr" ? `

---

` : n === "br" ? `
` : Array.from(t.childNodes).map((r) => l(r, i)).join("");
}
function l(t, i) {
  return t.nodeType === 3 ? t.textContent || "" : t.nodeType === 1 ? m(t, i) : "";
}
function g(t, i) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const r = new DOMParser().parseFromString(f(t), "text/html");
    return Array.from(r.body.childNodes).map((o) => l(o, i)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return f(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (n, r) => `

> ${r.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (n, r, e) => `

${"#".repeat(Number(r))} ${e.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function w(t, i = "article", n = [], r = "", e) {
  const o = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), a = [
    "---",
    `title: ${JSON.stringify(t.title || "未命名网页")}`,
    `url: ${JSON.stringify(t.url || "")}`,
    `clipped_at: ${JSON.stringify(o)}`,
    t.author ? `author: ${JSON.stringify(t.author)}` : null,
    t.siteName ? `site_name: ${JSON.stringify(t.siteName)}` : null,
    n.length ? `tags:
${n.map((c) => `  - ${JSON.stringify(c)}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((c) => c !== null).join(`
`), s = [`# ${t.title || "未命名网页"}`, "", `> 原文链接: [${t.url}](${t.url})`, t.author ? `> 作者: ${t.author}` : null, `> 剪藏时间: ${o.slice(0, 19).replace("T", " ")}`, ""].filter((c) => c !== null).join(`
`), d = r.trim() ? `
### 📝 我的笔记与标注

${r.trim()}

---
` : "";
  let u = "";
  if (i === "bookmark")
    u = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (i === "selection")
    u = `
### 摘录内容

${t.selectedHtml ? g(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let c = t.articleHtml ? g(t.articleHtml, t.url) : "";
    c.trim() || (c = t.articleText ? t.articleText : t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), u = `
${c}
`;
  }
  if (e !== void 0) {
    const c = {
      title: t.title || "未命名网页",
      url: t.url,
      author: t.author || "",
      site: t.siteName || "",
      description: t.description || "",
      date: o.slice(0, 10),
      content: u.trim(),
      notes: r.trim(),
      tags: n.join(", ")
    };
    return `${a}
${e.replace(/\{\{\s*(\w+)\s*\}\}/g, (h, y) => c[y] ?? h)}
`;
  }
  return `${a}
${s}${d}${u}`;
}
export {
  w as buildClipMarkdown,
  b as checkVesselStatus,
  f as cleanHtml,
  A as copyTextToClipboard,
  x as downloadMarkdownFile,
  m as elementToMarkdown,
  g as htmlToMarkdown,
  l as nodeToMarkdown,
  p as resolveUrl,
  S as saveClipToVessel
};
