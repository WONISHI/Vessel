function u(t, o) {
  try {
    return new URL(t, o).href;
  } catch {
    return t;
  }
}
function p(t) {
  return t.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, "").replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "").replace(/<svg\b[\s\S]*?<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function $(t, o) {
  const n = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(n))
    return "";
  if (/^h[1-6]$/.test(n)) {
    const r = parseInt(n[1], 10), e = t.textContent?.trim() || "";
    return `

${"#".repeat(r)} ${e}

`;
  }
  if (n === "p") {
    const r = Array.from(t.childNodes).map((e) => l(e, o)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (["div", "section", "article", "figure", "header", "main", "aside", "details", "summary"].includes(n)) {
    const r = Array.from(t.childNodes).map((e) => l(e, o)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (n === "strong" || n === "b") {
    const r = t.textContent?.trim() || "";
    return r ? `**${r}**` : "";
  }
  if (n === "em" || n === "i") {
    const r = t.textContent?.trim() || "";
    return r ? `*${r}*` : "";
  }
  if (n === "del" || n === "s" || n === "strike") {
    const r = t.textContent?.trim() || "";
    return r ? `~~${r}~~` : "";
  }
  if (n === "a") {
    const r = t.getAttribute("href"), e = t.textContent?.trim() || r || "";
    if (!r) return e;
    const i = u(r, o);
    return `[${e}](${i})`;
  }
  if (n === "img") {
    const r = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!r) return "";
    const e = t.getAttribute("alt") || "image", i = u(r, o);
    return `

![${e}](${i})

`;
  }
  if (n === "pre") {
    const r = t.querySelector("code"), e = (r ? r.textContent : t.textContent) || "";
    let i = "";
    const c = (r?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return c && (i = c[1]), `

\`\`\`${i}
${e.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (n === "code")
    return `\`${t.textContent || ""}\``;
  if (n === "blockquote")
    return `

${Array.from(t.childNodes).map((e) => l(e, o)).join("").trim().split(`
`).map((e) => `> ${e}`).join(`
`)}

`;
  if (n === "ul")
    return `

${Array.from(t.children).filter((e) => e.tagName.toLowerCase() === "li").map((e) => `- ${Array.from(e.childNodes).map((s) => l(s, o)).join("").trim()}`).join(`
`)}

`;
  if (n === "ol")
    return `

${Array.from(t.children).filter((e) => e.tagName.toLowerCase() === "li").map((e, i) => {
      const s = Array.from(e.childNodes).map((c) => l(c, o)).join("").trim();
      return `${i + 1}. ${s}`;
    }).join(`
`)}

`;
  if (n === "table") {
    const r = Array.from(t.querySelectorAll("tr"));
    if (!r.length) return "";
    let e = `

`;
    return r.forEach((i, s) => {
      const c = Array.from(i.querySelectorAll("th, td")).map((d) => d.textContent?.trim().replace(/\|/g, "\\|") || "");
      c.length && (e += `| ${c.join(" | ")} |
`, s === 0 && (e += `| ${c.map(() => "---").join(" | ")} |
`));
    }), e + `
`;
  }
  return n === "hr" ? `

---

` : n === "br" ? `
` : Array.from(t.childNodes).map((r) => l(r, o)).join("");
}
function l(t, o) {
  return t.nodeType === 3 ? t.textContent || "" : t.nodeType === 1 ? $(t, o) : "";
}
function f(t, o) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const r = new DOMParser().parseFromString(p(t), "text/html");
    return Array.from(r.body.childNodes).map((i) => l(i, o)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return p(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (n, r) => `

> ${r.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (n, r, e) => `

${"#".repeat(Number(r))} ${e.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function h(t, o = "article", n = [], r = "") {
  const e = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), i = [
    "---",
    `title: "${(t.title || "未命名网页").replace(/"/g, '\\"')}"`,
    `url: "${t.url || ""}"`,
    `clipped_at: "${e}"`,
    t.author ? `author: "${t.author.replace(/"/g, '\\"')}"` : null,
    t.siteName ? `site_name: "${t.siteName.replace(/"/g, '\\"')}"` : null,
    n.length ? `tags:
${n.map((a) => `  - ${a}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((a) => a !== null).join(`
`), s = [
    `# ${t.title || "未命名网页"}`,
    "",
    `> 原文链接: [${t.url}](${t.url})`,
    t.author ? `> 作者: ${t.author}` : null,
    `> 剪藏时间: ${e.slice(0, 19).replace("T", " ")}`,
    ""
  ].filter((a) => a !== null).join(`
`), c = r.trim() ? `
### 📝 我的笔记与标注

${r.trim()}

---
` : "";
  let d = "";
  if (o === "bookmark")
    d = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (o === "selection")
    d = `
### 摘录内容

${t.selectedHtml ? f(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let a = t.articleHtml ? f(t.articleHtml, t.url) : "";
    a.trim() || (a = t.articleText ? t.articleText : t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), d = `
${a}
`;
  }
  return `${i}
${s}${c}${d}`;
}
const g = "http://127.0.0.1:35678";
async function m() {
  try {
    const t = new AbortController(), o = setTimeout(() => t.abort(), 1200), n = await fetch(`${g}/api/status`, {
      method: "GET",
      signal: t.signal
    });
    return clearTimeout(o), n.ok ? await n.json() : null;
  } catch {
    return null;
  }
}
async function y(t) {
  try {
    return await (await fetch(`${g}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (o) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(o)}`
    };
  }
}
function b(t, o) {
  const n = new Blob([o], { type: "text/markdown;charset=utf-8" }), r = URL.createObjectURL(n);
  if (typeof chrome < "u" && chrome.downloads?.download)
    chrome.downloads.download({
      url: r,
      filename: t,
      saveAs: !1
    });
  else {
    const e = document.createElement("a");
    e.href = r, e.download = t, document.body.appendChild(e), e.click(), document.body.removeChild(e);
  }
}
async function x(t) {
  try {
    if (navigator.clipboard)
      return await navigator.clipboard.writeText(t), !0;
  } catch {
  }
  return !1;
}
export {
  h as buildClipMarkdown,
  m as checkVesselStatus,
  p as cleanHtml,
  x as copyTextToClipboard,
  b as downloadMarkdownFile,
  $ as elementToMarkdown,
  f as htmlToMarkdown,
  l as nodeToMarkdown,
  u as resolveUrl,
  y as saveClipToVessel
};
