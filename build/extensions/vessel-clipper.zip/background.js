const m = "http://127.0.0.1:35678";
async function h(t) {
  try {
    return await (await fetch(`${m}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (i) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(i)}`
    };
  }
}
function f(t, i) {
  try {
    return new URL(t, i).href;
  } catch {
    return t;
  }
}
function g(t) {
  return t.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, "").replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "").replace(/<svg\b[\s\S]*?<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function y(t, i) {
  const r = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(r))
    return "";
  if (/^h[1-6]$/.test(r)) {
    const e = parseInt(r[1], 10), n = t.textContent?.trim() || "";
    return `

${"#".repeat(e)} ${n}

`;
  }
  if (r === "p") {
    const e = Array.from(t.childNodes).map((n) => d(n, i)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (["div", "section", "article", "figure", "header", "main", "aside", "details", "summary"].includes(r)) {
    const e = Array.from(t.childNodes).map((n) => d(n, i)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (r === "strong" || r === "b") {
    const e = t.textContent?.trim() || "";
    return e ? `**${e}**` : "";
  }
  if (r === "em" || r === "i") {
    const e = t.textContent?.trim() || "";
    return e ? `*${e}*` : "";
  }
  if (r === "del" || r === "s" || r === "strike") {
    const e = t.textContent?.trim() || "";
    return e ? `~~${e}~~` : "";
  }
  if (r === "a") {
    const e = t.getAttribute("href"), n = t.textContent?.trim() || e || "";
    if (!e) return n;
    const o = f(e, i);
    return `[${n}](${o})`;
  }
  if (r === "img") {
    const e = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!e) return "";
    const n = t.getAttribute("alt") || "image", o = f(e, i);
    return `

![${n}](${o})

`;
  }
  if (r === "pre") {
    const e = t.querySelector("code"), n = (e ? e.textContent : t.textContent) || "";
    let o = "";
    const s = (e?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return s && (o = s[1]), `

\`\`\`${o}
${n.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (r === "code")
    return `\`${t.textContent || ""}\``;
  if (r === "blockquote")
    return `

${Array.from(t.childNodes).map((n) => d(n, i)).join("").trim().split(`
`).map((n) => `> ${n}`).join(`
`)}

`;
  if (r === "ul")
    return `

${Array.from(t.children).filter((n) => n.tagName.toLowerCase() === "li").map((n) => `- ${Array.from(n.childNodes).map((c) => d(c, i)).join("").trim()}`).join(`
`)}

`;
  if (r === "ol")
    return `

${Array.from(t.children).filter((n) => n.tagName.toLowerCase() === "li").map((n, o) => {
      const c = Array.from(n.childNodes).map((s) => d(s, i)).join("").trim();
      return `${o + 1}. ${c}`;
    }).join(`
`)}

`;
  if (r === "table") {
    const e = Array.from(t.querySelectorAll("tr"));
    if (!e.length) return "";
    let n = `

`;
    return e.forEach((o, c) => {
      const s = Array.from(o.querySelectorAll("th, td")).map((p) => p.textContent?.trim().replace(/\|/g, "\\|") || "");
      s.length && (n += `| ${s.join(" | ")} |
`, c === 0 && (n += `| ${s.map(() => "---").join(" | ")} |
`));
    }), n + `
`;
  }
  return r === "hr" ? `

---

` : r === "br" ? `
` : Array.from(t.childNodes).map((e) => d(e, i)).join("");
}
function d(t, i) {
  return t.nodeType === 3 ? (t.textContent || "").replace(/[\t\n\r\f ]+/g, " ") : t.nodeType === 1 ? y(t, i) : "";
}
function $(t, i) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const e = new DOMParser().parseFromString(g(t), "text/html");
    return Array.from(e.body.childNodes).map((o) => d(o, i)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return g(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (r, e) => `

> ${e.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (r, e, n) => `

${"#".repeat(Number(e))} ${n.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function x(t, i = "article", r = [], e = "", n) {
  const o = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), c = [
    "---",
    `title: ${JSON.stringify(t.title || "未命名网页")}`,
    `url: ${JSON.stringify(t.url || "")}`,
    `clipped_at: ${JSON.stringify(o)}`,
    t.author ? `author: ${JSON.stringify(t.author)}` : null,
    t.siteName ? `site_name: ${JSON.stringify(t.siteName)}` : null,
    r.length ? `tags:
${r.map((l) => `  - ${JSON.stringify(l)}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((l) => l !== null).join(`
`), s = [`# ${t.title || "未命名网页"}`, "", `> 原文链接: [${t.url}](${t.url})`, t.author ? `> 作者: ${t.author}` : null, `> 剪藏时间: ${o.slice(0, 19).replace("T", " ")}`, ""].filter((l) => l !== null).join(`
`), p = e.trim() ? `
### 📝 我的笔记与标注

${e.trim()}

---
` : "";
  let u = "";
  if (i === "bookmark")
    u = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (i === "selection")
    u = `
### 摘录内容

${t.selectedHtml ? $(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let l = t.articleHtml ? $(t.articleHtml, t.url) : "";
    l.trim() || (l = t.articleText ? t.articleText : t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), u = `
${l}
`;
  }
  return `${c}
${s}${p}${u}`;
}
const a = typeof chrome < "u" ? chrome.contextMenus : void 0;
if (a && typeof a.create == "function" && a.onClicked)
  try {
    chrome.runtime?.onInstalled?.addListener(() => {
      try {
        a.removeAll?.(() => {
          a.create({
            id: "vessel-clip-page",
            title: "剪藏整个网页到 Vessel",
            contexts: ["page"]
          }), a.create({
            id: "vessel-clip-selection",
            title: "剪藏选中文本到 Vessel",
            contexts: ["selection"]
          }), a.create({
            id: "vessel-clip-link",
            title: "剪藏链接到 Vessel",
            contexts: ["link"]
          });
        });
      } catch {
      }
    }), a.onClicked.addListener(async (t, i) => {
      if (!i || !i.id || !i.url) return;
      let r = {
        title: i.title || "未命名网页",
        url: i.url,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      try {
        const s = await chrome.tabs?.sendMessage(i.id, { type: "GET_PAGE_DATA" });
        s && (r = s);
      } catch {
      }
      let e = "article";
      t.menuItemId === "vessel-clip-selection" ? (e = "selection", r.selectedText = t.selectionText || r.selectedText) : t.menuItemId === "vessel-clip-link" && (e = "bookmark", r.url = t.linkUrl || r.url, r.title = `链接: ${r.url}`);
      const n = x(r, e, ["快捷剪藏"]), o = await h({
        title: r.title,
        url: r.url,
        markdown: n,
        tags: ["快捷剪藏"],
        folder: "Clippings",
        mode: e
      }), c = typeof chrome < "u" ? chrome.action : void 0;
      c && typeof c.setBadgeText == "function" && (o.ok ? (await c.setBadgeText({ text: "✓", tabId: i.id }), await c.setBadgeBackgroundColor?.({ color: "#16a34a", tabId: i.id }), setTimeout(() => {
        c.setBadgeText?.({ text: "", tabId: i.id });
      }, 2500)) : (await c.setBadgeText({ text: "!", tabId: i.id }), await c.setBadgeBackgroundColor?.({ color: "#dc2626", tabId: i.id }), setTimeout(() => {
        c.setBadgeText?.({ text: "", tabId: i.id });
      }, 3e3)));
    });
  } catch (t) {
    console.warn("[Clipper Background] Failed to setup contextMenus:", t);
  }
