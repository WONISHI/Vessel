const f = "http://127.0.0.1:35678";
async function $(t) {
  try {
    return await (await fetch(`${f}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (i) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(i)}`
    };
  }
}
function u(t, i) {
  try {
    return new URL(t, i).href;
  } catch {
    return t;
  }
}
function p(t) {
  return t.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "").replace(/<noscript\b[^<]*(?:(?!<\/noscript>)<[^<]*)*<\/noscript>/gi, "").replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "").replace(/<svg\b[^<]*(?:(?!<\/svg>)<[^<]*)*<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function m(t, i) {
  const r = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(r))
    return "";
  if (/^h[1-6]$/.test(r)) {
    const e = parseInt(r[1], 10), n = t.textContent?.trim() || "";
    return `

${"#".repeat(e)} ${n}

`;
  }
  if (r === "p") {
    const e = Array.from(t.childNodes).map((n) => a(n, i)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (["div", "section", "article", "figure", "header"].includes(r)) {
    const e = Array.from(t.childNodes).map((n) => a(n, i)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (r === "strong" || r === "b") {
    const e = t.textContent?.trim() || "";
    return e ? `**${e}**` : "";
  }
  if (r === "em" || r === "i") {
    const e = t.textContent?.trim() || "";
    return e ? `*${e}*` : "";
  }
  if (r === "del" || r === "s" || r === "strike") {
    const e = t.textContent?.trim() || "";
    return e ? `~~${e}~~` : "";
  }
  if (r === "a") {
    const e = t.getAttribute("href"), n = t.textContent?.trim() || e || "";
    if (!e) return n;
    const o = u(e, i);
    return `[${n}](${o})`;
  }
  if (r === "img") {
    const e = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!e) return "";
    const n = t.getAttribute("alt") || "image", o = u(e, i);
    return `

![${n}](${o})

`;
  }
  if (r === "pre") {
    const e = t.querySelector("code"), n = (e ? e.textContent : t.textContent) || "";
    let o = "";
    const s = (e?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return s && (o = s[1]), `

\`\`\`${o}
${n.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (r === "code")
    return `\`${t.textContent || ""}\``;
  if (r === "blockquote")
    return `

${Array.from(t.childNodes).map((n) => a(n, i)).join("").trim().split(`
`).map((n) => `> ${n}`).join(`
`)}

`;
  if (r === "ul")
    return `

${Array.from(t.children).filter((n) => n.tagName.toLowerCase() === "li").map((n) => `- ${Array.from(n.childNodes).map((c) => a(c, i)).join("").trim()}`).join(`
`)}

`;
  if (r === "ol")
    return `

${Array.from(t.children).filter((n) => n.tagName.toLowerCase() === "li").map((n, o) => {
      const c = Array.from(n.childNodes).map((s) => a(s, i)).join("").trim();
      return `${o + 1}. ${c}`;
    }).join(`
`)}

`;
  if (r === "table") {
    const e = Array.from(t.querySelectorAll("tr"));
    if (!e.length) return "";
    let n = `

`;
    return e.forEach((o, c) => {
      const s = Array.from(o.querySelectorAll("th, td")).map((d) => d.textContent?.trim().replace(/\|/g, "\\|") || "");
      s.length && (n += `| ${s.join(" | ")} |
`, c === 0 && (n += `| ${s.map(() => "---").join(" | ")} |
`));
    }), n + `
`;
  }
  return r === "hr" ? `

---

` : r === "br" ? `
` : Array.from(t.childNodes).map((e) => a(e, i)).join("");
}
function a(t, i) {
  return t.nodeType === 3 ? t.textContent || "" : t.nodeType === 1 ? m(t, i) : "";
}
function g(t, i) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const e = new DOMParser().parseFromString(p(t), "text/html");
    return Array.from(e.body.childNodes).map((o) => a(o, i)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return p(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (r, e) => `

> ${e.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (r, e, n) => `

${"#".repeat(Number(e))} ${n.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function h(t, i = "article", r = [], e = "") {
  const n = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), o = [
    "---",
    `title: "${(t.title || "未命名网页").replace(/"/g, '\\"')}"`,
    `url: "${t.url || ""}"`,
    `clipped_at: "${n}"`,
    t.author ? `author: "${t.author.replace(/"/g, '\\"')}"` : null,
    t.siteName ? `site_name: "${t.siteName.replace(/"/g, '\\"')}"` : null,
    r.length ? `tags:
${r.map((l) => `  - ${l}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((l) => l !== null).join(`
`), c = [
    `# ${t.title || "未命名网页"}`,
    "",
    `> 原文链接: [${t.url}](${t.url})`,
    t.author ? `> 作者: ${t.author}` : null,
    `> 剪藏时间: ${n.slice(0, 19).replace("T", " ")}`,
    ""
  ].filter((l) => l !== null).join(`
`), s = e.trim() ? `
### 📝 我的笔记与标注

${e.trim()}

---
` : "";
  let d = "";
  if (i === "bookmark")
    d = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (i === "selection")
    d = `
### 摘录内容

${t.selectedHtml ? g(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let l = t.articleHtml ? g(t.articleHtml, t.url) : "";
    l.trim() || (l = t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), d = `
${l}
`;
  }
  return `${o}
${c}${s}${d}`;
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "vessel-clip-page",
      title: "剪藏整个网页到 Vessel",
      contexts: ["page"]
    }), chrome.contextMenus.create({
      id: "vessel-clip-selection",
      title: "剪藏选中文本到 Vessel",
      contexts: ["selection"]
    }), chrome.contextMenus.create({
      id: "vessel-clip-link",
      title: "剪藏链接到 Vessel",
      contexts: ["link"]
    });
  });
});
chrome.contextMenus.onClicked.addListener(async (t, i) => {
  if (!i || !i.id || !i.url) return;
  let r = {
    title: i.title || "未命名网页",
    url: i.url,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    const c = await chrome.tabs.sendMessage(i.id, { type: "GET_PAGE_DATA" });
    c && (r = c);
  } catch {
  }
  let e = "article";
  t.menuItemId === "vessel-clip-selection" ? (e = "selection", r.selectedText = t.selectionText || r.selectedText) : t.menuItemId === "vessel-clip-link" && (e = "bookmark", r.url = t.linkUrl || r.url, r.title = `链接: ${r.url}`);
  const n = h(r, e, ["快捷剪藏"]);
  (await $({
    title: r.title,
    url: r.url,
    markdown: n,
    tags: ["快捷剪藏"],
    folder: "Clippings",
    mode: e
  })).ok ? (await chrome.action.setBadgeText({ text: "✓", tabId: i.id }), await chrome.action.setBadgeBackgroundColor({ color: "#16a34a", tabId: i.id }), setTimeout(() => {
    chrome.action.setBadgeText({ text: "", tabId: i.id });
  }, 2500)) : (await chrome.action.setBadgeText({ text: "!", tabId: i.id }), await chrome.action.setBadgeBackgroundColor({ color: "#dc2626", tabId: i.id }), setTimeout(() => {
    chrome.action.setBadgeText({ text: "", tabId: i.id });
  }, 3e3));
});
