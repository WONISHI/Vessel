const F = "http://127.0.0.1:35678";
async function X() {
  try {
    const e = new AbortController(), i = setTimeout(() => e.abort(), 1200), t = await fetch(`${F}/api/status`, {
      method: "GET",
      signal: e.signal
    });
    return clearTimeout(i), t.ok ? await t.json() : null;
  } catch {
    return null;
  }
}
async function Y(e) {
  try {
    return await (await fetch(`${F}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(e)
    })).json();
  } catch (i) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(i)}`
    };
  }
}
function ee(e, i) {
  const t = new Blob([i], { type: "text/markdown;charset=utf-8" }), r = URL.createObjectURL(t), n = document.createElement("a");
  n.href = r, n.download = e, document.body.appendChild(n), n.click(), document.body.removeChild(n), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
async function te(e) {
  try {
    if (navigator.clipboard)
      return await navigator.clipboard.writeText(e), !0;
  } catch {
  }
  return !1;
}
function D(e, i) {
  try {
    return new URL(e, i).href;
  } catch {
    return e;
  }
}
function z(e) {
  return e.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, "").replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "").replace(/<svg\b[\s\S]*?<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function ne(e, i) {
  const t = e.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(t))
    return "";
  if (/^h[1-6]$/.test(t)) {
    const r = parseInt(t[1], 10), n = e.textContent?.trim() || "";
    return `

${"#".repeat(r)} ${n}

`;
  }
  if (t === "p") {
    const r = Array.from(e.childNodes).map((n) => x(n, i)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (["div", "section", "article", "figure", "header", "main", "aside", "details", "summary"].includes(t)) {
    const r = Array.from(e.childNodes).map((n) => x(n, i)).join("").trim();
    return r ? `

${r}

` : "";
  }
  if (t === "strong" || t === "b") {
    const r = e.textContent?.trim() || "";
    return r ? `**${r}**` : "";
  }
  if (t === "em" || t === "i") {
    const r = e.textContent?.trim() || "";
    return r ? `*${r}*` : "";
  }
  if (t === "del" || t === "s" || t === "strike") {
    const r = e.textContent?.trim() || "";
    return r ? `~~${r}~~` : "";
  }
  if (t === "a") {
    const r = e.getAttribute("href"), n = e.textContent?.trim() || r || "";
    if (!r) return n;
    const o = D(r, i);
    return `[${n}](${o})`;
  }
  if (t === "img") {
    const r = e.getAttribute("src") || e.getAttribute("data-src") || e.getAttribute("data-original-src") || e.getAttribute("data-actualsrc") || e.getAttribute("data-lazy-src");
    if (!r) return "";
    const n = e.getAttribute("alt") || "image", o = D(r, i);
    return `

![${n}](${o})

`;
  }
  if (t === "pre") {
    const r = e.querySelector("code"), n = (r ? r.textContent : e.textContent) || "";
    let o = "";
    const a = (r?.getAttribute("class") || e.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return a && (o = a[1]), `

\`\`\`${o}
${n.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (t === "code")
    return `\`${e.textContent || ""}\``;
  if (t === "blockquote")
    return `

${Array.from(e.childNodes).map((n) => x(n, i)).join("").trim().split(`
`).map((n) => `> ${n}`).join(`
`)}

`;
  if (t === "ul")
    return `

${Array.from(e.children).filter((n) => n.tagName.toLowerCase() === "li").map((n) => `- ${Array.from(n.childNodes).map((u) => x(u, i)).join("").trim()}`).join(`
`)}

`;
  if (t === "ol")
    return `

${Array.from(e.children).filter((n) => n.tagName.toLowerCase() === "li").map((n, o) => {
      const u = Array.from(n.childNodes).map((a) => x(a, i)).join("").trim();
      return `${o + 1}. ${u}`;
    }).join(`
`)}

`;
  if (t === "table") {
    const r = Array.from(e.querySelectorAll("tr"));
    if (!r.length) return "";
    let n = `

`;
    return r.forEach((o, u) => {
      const a = Array.from(o.querySelectorAll("th, td")).map((S) => S.textContent?.trim().replace(/\|/g, "\\|") || "");
      a.length && (n += `| ${a.join(" | ")} |
`, u === 0 && (n += `| ${a.map(() => "---").join(" | ")} |
`));
    }), n + `
`;
  }
  return t === "hr" ? `

---

` : t === "br" ? `
` : Array.from(e.childNodes).map((r) => x(r, i)).join("");
}
function x(e, i) {
  return e.nodeType === 3 ? (e.textContent || "").replace(/[\t\n\r\f ]+/g, " ") : e.nodeType === 1 ? ne(e, i) : "";
}
function G(e, i) {
  if (!e) return "";
  if (typeof DOMParser < "u") {
    const r = new DOMParser().parseFromString(z(e), "text/html");
    return Array.from(r.body.childNodes).map((o) => x(o, i)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return z(e).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (t, r) => `

> ${r.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (t, r, n) => `

${"#".repeat(Number(r))} ${n.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function re(e, i = "article", t = [], r = "", n) {
  const o = e.timestamp || (/* @__PURE__ */ new Date()).toISOString(), u = [
    "---",
    `title: ${JSON.stringify(e.title || "未命名网页")}`,
    `url: ${JSON.stringify(e.url || "")}`,
    `clipped_at: ${JSON.stringify(o)}`,
    e.author ? `author: ${JSON.stringify(e.author)}` : null,
    e.siteName ? `site_name: ${JSON.stringify(e.siteName)}` : null,
    t.length ? `tags:
${t.map((c) => `  - ${JSON.stringify(c)}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((c) => c !== null).join(`
`), a = [`# ${e.title || "未命名网页"}`, "", `> 原文链接: [${e.url}](${e.url})`, e.author ? `> 作者: ${e.author}` : null, `> 剪藏时间: ${o.slice(0, 19).replace("T", " ")}`, ""].filter((c) => c !== null).join(`
`), S = r.trim() ? `
### 📝 我的笔记与标注

${r.trim()}

---
` : "";
  let $ = "";
  if (i === "bookmark")
    $ = e.description ? `
### 简介

${e.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (i === "selection")
    $ = `
### 摘录内容

${e.selectedHtml ? G(e.selectedHtml, e.url) : e.selectedText || ""}
`;
  else {
    let c = e.articleHtml ? G(e.articleHtml, e.url) : "";
    c.trim() || (c = e.articleText ? e.articleText : e.selectedText ? `### 摘录内容

${e.selectedText}` : e.description ? `### 页面简介

${e.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), $ = `
${c}
`;
  }
  if (n !== void 0) {
    const c = {
      title: e.title || "未命名网页",
      url: e.url,
      author: e.author || "",
      site: e.siteName || "",
      description: e.description || "",
      date: o.slice(0, 10),
      content: $.trim(),
      notes: r.trim(),
      tags: t.join(", ")
    };
    return `${u}
${n.replace(/\{\{\s*(\w+)\s*\}\}/g, (k, A) => c[A] ?? k)}
`;
  }
  return `${u}
${a}${S}${$}`;
}
let s = {
  title: "网页剪藏",
  url: "",
  timestamp: (/* @__PURE__ */ new Date()).toISOString()
}, I = "article", P = !1, h = null, O = "default", w = !1;
const g = document.getElementById("clip-template"), N = document.getElementById("template-body"), H = document.getElementById("clip-author"), J = document.getElementById("clip-site"), ie = document.getElementById("clip-source"), oe = `# {{title}}

> 来源：[{{site}}]({{url}}) · {{date}}

{{content}}`, q = `# {{title}}

[原文]({{url}}) · {{author}} · {{date}}

{{content}}

{{notes}}`;
let U = !1;
async function Z(e) {
  try {
    const i = typeof chrome < "u" ? chrome.storage?.local : void 0;
    if (e === "read") {
      const t = i ? (await i.get("clipperPreferences")).clipperPreferences : JSON.parse(localStorage.getItem("clipperPreferences") || "null");
      t && typeof t == "object" && (typeof t.folder == "string" && (j.value = t.folder), typeof t.tags == "string" && (B.value = t.tags), ["default", "quote", "custom"].includes(t.template) && (g.value = t.template), typeof t.body == "string" && (N.value = t.body === q.replace("{{notes}}", `## 阅读笔记

{{notes}}`) ? q : t.body));
    } else {
      const t = { folder: j?.value, tags: B?.value, template: g.value, body: N.value };
      i ? await i.set({ clipperPreferences: t }) : localStorage.setItem("clipperPreferences", JSON.stringify(t));
    }
  } catch {
  }
}
function W() {
  document.getElementById("template-settings").hidden = g.value !== "custom";
}
const T = document.getElementById("clip-title"), j = document.getElementById("clip-folder"), B = document.getElementById("clip-tags"), K = document.getElementById("clip-notes"), f = document.getElementById("preview-content"), M = document.getElementById("toggle-preview-btn"), m = document.getElementById("connection-status"), E = m?.querySelector(".text"), C = document.getElementById("message-bar"), v = document.getElementById("save-btn"), _ = document.getElementById("download-btn"), R = document.getElementById("copy-btn"), Q = document.querySelectorAll(".tab-btn");
function b(e, i = "success") {
  C && (C.textContent = e, C.className = `message-bar ${i}`, setTimeout(() => {
    C && (C.className = "message-bar");
  }, 4e3));
}
function d() {
  const e = (B?.value || "").split(/[,，\s]+/).map((o) => o.trim()).filter(Boolean), i = K?.value || "", t = re(
    {
      ...s,
      title: T?.value || s.title,
      author: H.value,
      siteName: J.value
    },
    I,
    e,
    i,
    g.value === "custom" ? N.value : g.value === "quote" ? oe + (i.trim() ? `

## 我的笔记

{{notes}}` : "") : `{{content}}

{{notes}}`
  );
  document.getElementById("edit-state").hidden = h === null;
  const r = t.match(/^---\n[\s\S]*?\n---\n/)?.[0] || "", n = h ?? t.slice(r.length).trim();
  return f && (f.value = w ? n : ""), document.getElementById("content-count").textContent = String(w ? n.length : 0), U && Z("write"), `${r}
${n}
`;
}
function V(e) {
  if (e === "selection" && !s.selectedText?.trim() && !s.selectedHtml?.trim()) {
    b("请先在网页中选择需要摘录的内容，再打开剪藏。", "error");
    return;
  }
  e !== I && h !== null && !window.confirm("切换模式将重新生成正文，是否继续？") || e !== I && (h = null, I = e, Q.forEach((i) => {
    i.dataset.mode === e ? i.classList.add("active") : i.classList.remove("active");
  }), d());
}
Q.forEach((e) => {
  e.addEventListener("click", () => {
    const i = e.dataset.mode;
    i && V(i);
  });
});
N.value = q;
f?.addEventListener("input", () => {
  h = f.value, document.getElementById("edit-state").hidden = !1, document.getElementById("content-count").textContent = String(f.value.length);
});
document.getElementById("reset-content")?.addEventListener("click", () => {
  h !== null && !window.confirm("重新生成将覆盖手动修改，是否继续？") || (h = null, d());
});
g.addEventListener("change", () => {
  if (h !== null && !window.confirm("应用模板将覆盖手动修改，是否继续？")) {
    g.value = O;
    return;
  }
  O = g.value, W(), h = null, d();
});
for (const e of [H, J, N, j]) e?.addEventListener("input", d);
T?.addEventListener("input", d);
B?.addEventListener("input", d);
K?.addEventListener("input", d);
M?.addEventListener("click", () => {
  if (!f || !M) return;
  f.classList.contains("hidden") ? (f.classList.remove("hidden"), M.classList.add("open")) : (f.classList.add("hidden"), M.classList.remove("open"));
});
R?.addEventListener("click", async () => {
  const e = d();
  await te(e) ? b("已复制 Markdown 内容至剪贴板", "success") : b("复制失败", "error");
});
_?.addEventListener("click", () => {
  const e = d(), t = (T?.value || s.title || "clip").replace(/[\\/:*?"<>|]/g, "-").trim();
  ee(`${t}.md`, e), b("已开始下载 Markdown 文件", "success");
});
v?.addEventListener("click", async () => {
  if (!v || !w) return;
  const e = d(), i = (B?.value || "").split(/[,，\s]+/).map((t) => t.trim()).filter(Boolean);
  v.disabled = !0, v.textContent = "保存中...";
  try {
    const t = await Y({
      title: T?.value || s.title,
      url: s.url,
      markdown: e,
      tags: i,
      folder: j?.value || "Clippings",
      description: s.description,
      author: H.value,
      mode: I
    });
    if (t.ok && t.success)
      b(`✅ 保存成功: ${t.relativePath || t.filename || ""}`, "success");
    else {
      const r = t.message || t.error || "保存失败，请检查桌面端状态";
      b(`❌ ${r}`, "error");
    }
  } catch (t) {
    b(`保存失败: ${String(t)}`, "error");
  } finally {
    v.disabled = !1, v.textContent = "保存到 Vessel";
  }
});
async function ce() {
  let e = null;
  const i = () => window.__vesselClipperPage;
  new URLSearchParams(location.search).get("vesselHost") === "1" && (e = i() || await new Promise((t) => {
    const r = () => {
      clearTimeout(n), window.removeEventListener("vessel:clipper-page-ready", r), t(i() || null);
    }, n = setTimeout(r, 1500);
    window.addEventListener("vessel:clipper-page-ready", r);
  }));
  try {
    if (e?.url) throw new Error("Page delivered directly by Vessel");
    if (new URLSearchParams(location.search).get("vesselHost") !== "1" && !("vesselPageBridge" in window)) throw new Error("Use the active browser tab");
    const t = await fetch("http://127.0.0.1:35678/api/active-page", { signal: AbortSignal.timeout(2e3) });
    if (t.ok) {
      const r = await t.json(), n = r.data || r;
      n && (n.url || n.title) && (e = {
        title: n.title || "未命名网页",
        url: n.url || "",
        description: n.description || "",
        author: n.author || "",
        siteName: n.siteName || "",
        favicon: n.favicon || "",
        articleHtml: n.articleHtml || "",
        articleText: n.articleText || "",
        selectedText: n.selectedText || "",
        selectedHtml: n.selectedHtml || "",
        timestamp: n.timestamp || (/* @__PURE__ */ new Date()).toISOString()
      });
    }
  } catch {
  }
  if (!e || !e.articleHtml && !e.articleText && !e.selectedText)
    try {
      if (typeof chrome < "u" && chrome.tabs?.query) {
        const r = (await chrome.tabs.query({ active: !0, currentWindow: !0 }).catch(() => []))[0];
        if (r && r.id && r.url && /^https?:\/\//i.test(r.url)) {
          try {
            const n = await chrome.tabs.sendMessage(r.id, { type: "GET_PAGE_DATA" }).catch(() => null);
            n && (n.articleHtml || n.articleText || n.selectedText || n.url) && (e = n);
          } catch {
          }
          if (!e && chrome.scripting?.executeScript)
            try {
              const n = await chrome.scripting.executeScript({
                target: { tabId: r.id },
                /** Performs the func operation. */
                func: () => {
                  const o = window.getSelection(), u = o ? o.toString().trim() : "";
                  let a = "";
                  if (o && o.rangeCount > 0 && !o.isCollapsed) {
                    const p = document.createElement("div");
                    p.appendChild(o.getRangeAt(0).cloneContents()), a = p.innerHTML;
                  }
                  function S(p) {
                    ["script", "style", "noscript", "iframe", "svg", "nav", "header", "footer", "aside", ".sidebar", ".comments", ".ad"].forEach((y) => {
                      p.querySelectorAll(y).forEach((L) => L.remove());
                    });
                  }
                  const $ = [
                    "#js_content",
                    ".Post-RichText",
                    ".RichContent-inner",
                    "#content_views",
                    ".article_content",
                    ".article-viewer",
                    ".markdown-body",
                    ".article-holder",
                    ".article-content",
                    "article",
                    "main",
                    "[role='main']",
                    ".post-content",
                    ".article-content",
                    ".entry-content",
                    "#article-root",
                    "#content",
                    ".article",
                    ".post_body",
                    ".post-body"
                  ];
                  let c = "", k = "";
                  for (const p of $) {
                    const l = document.querySelector(p);
                    if (l && (l.innerText || l.textContent || "").trim().length > 20) {
                      const y = l.cloneNode(!0);
                      S(y), c = y.innerHTML, k = (y.innerText || "").trim();
                      break;
                    }
                  }
                  if (!c) {
                    const p = document.body || document.documentElement;
                    if (p) {
                      const l = p.cloneNode(!0);
                      S(l), c = l.innerHTML, k = (l.innerText || "").trim();
                    }
                  }
                  const A = (p) => {
                    for (const l of p) {
                      const y = document.querySelector(`meta[name='${l}'], meta[property='${l}']`);
                      if (y) {
                        const L = y.getAttribute("content");
                        if (L) return L.trim();
                      }
                    }
                    return "";
                  };
                  return {
                    title: document.title || "未命名网页",
                    url: window.location.href,
                    description: A(["description", "og:description", "twitter:description"]),
                    author: A(["author", "article:author", "twitter:creator"]),
                    siteName: A(["og:site_name", "application-name"]) || window.location.hostname,
                    selectedText: u,
                    selectedHtml: a,
                    articleHtml: c,
                    articleText: k,
                    timestamp: (/* @__PURE__ */ new Date()).toISOString()
                  };
                }
              });
              n && n[0]?.result && (e = n[0].result);
            } catch (n) {
              console.warn("executeScript fallback error:", n);
            }
        }
      }
    } catch (t) {
      console.warn("Chrome tab query error:", t);
    }
  e && (s = e, H.value = s.author || "", J.value = s.siteName || "", ie.value = s.url, T && s.title && (T.value = s.title), s.selectedText && s.selectedText.trim() ? V("selection") : V("article")), w = !!e?.url, w || b("未能读取当前网页，请刷新网页后重新打开剪藏。", "error"), v && (v.disabled = !w), R && (R.disabled = !w), _ && (_.disabled = !w), d();
}
async function se() {
  await Z("read"), O = g.value, U = !0, W(), d();
  const e = ce();
  try {
    const i = await X();
    if (i && i.ok) {
      P = !0, m && (m.className = "status-badge connected");
      const t = "已连接 Vessel";
      m && (m.title = i.workspace?.name ? `当前工作区：${i.workspace.name}` : "尚未打开工作区"), E && (E.textContent = t);
    } else
      P = !1, m && (m.className = "status-badge disconnected"), E && (E.textContent = "未连接桌面端");
  } catch (i) {
    console.error("Vessel check error:", i), P = !1, m && (m.className = "status-badge disconnected"), E && (E.textContent = "未连接桌面端");
  }
  await e;
}
se();
