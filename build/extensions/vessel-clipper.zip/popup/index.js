const H = "http://127.0.0.1:35678";
async function _() {
  try {
    const t = new AbortController(), n = setTimeout(() => t.abort(), 1200), r = await fetch(`${H}/api/status`, {
      method: "GET",
      signal: t.signal
    });
    return clearTimeout(n), r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}
async function q(t) {
  try {
    return await (await fetch(`${H}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (n) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(n)}`
    };
  }
}
function P(t, n) {
  const r = new Blob([n], { type: "text/markdown;charset=utf-8" }), e = URL.createObjectURL(r);
  if (typeof chrome < "u" && chrome.downloads?.download)
    chrome.downloads.download({
      url: e,
      filename: t,
      saveAs: !1
    });
  else {
    const o = document.createElement("a");
    o.href = e, o.download = t, document.body.appendChild(o), o.click(), document.body.removeChild(o);
  }
}
async function V(t) {
  try {
    if (navigator.clipboard)
      return await navigator.clipboard.writeText(t), !0;
  } catch {
  }
  return !1;
}
function M(t, n) {
  try {
    return new URL(t, n).href;
  } catch {
    return t;
  }
}
function N(t) {
  return t.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "").replace(/<noscript\b[^<]*(?:(?!<\/noscript>)<[^<]*)*<\/noscript>/gi, "").replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "").replace(/<svg\b[^<]*(?:(?!<\/svg>)<[^<]*)*<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function O(t, n) {
  const r = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(r))
    return "";
  if (/^h[1-6]$/.test(r)) {
    const e = parseInt(r[1], 10), o = t.textContent?.trim() || "";
    return `

${"#".repeat(e)} ${o}

`;
  }
  if (r === "p") {
    const e = Array.from(t.childNodes).map((o) => f(o, n)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (["div", "section", "article", "figure", "header"].includes(r)) {
    const e = Array.from(t.childNodes).map((o) => f(o, n)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (r === "strong" || r === "b") {
    const e = t.textContent?.trim() || "";
    return e ? `**${e}**` : "";
  }
  if (r === "em" || r === "i") {
    const e = t.textContent?.trim() || "";
    return e ? `*${e}*` : "";
  }
  if (r === "del" || r === "s" || r === "strike") {
    const e = t.textContent?.trim() || "";
    return e ? `~~${e}~~` : "";
  }
  if (r === "a") {
    const e = t.getAttribute("href"), o = t.textContent?.trim() || e || "";
    if (!e) return o;
    const c = M(e, n);
    return `[${o}](${c})`;
  }
  if (r === "img") {
    const e = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!e) return "";
    const o = t.getAttribute("alt") || "image", c = M(e, n);
    return `

![${o}](${c})

`;
  }
  if (r === "pre") {
    const e = t.querySelector("code"), o = (e ? e.textContent : t.textContent) || "";
    let c = "";
    const s = (e?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return s && (c = s[1]), `

\`\`\`${c}
${o.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (r === "code")
    return `\`${t.textContent || ""}\``;
  if (r === "blockquote")
    return `

${Array.from(t.childNodes).map((o) => f(o, n)).join("").trim().split(`
`).map((o) => `> ${o}`).join(`
`)}

`;
  if (r === "ul")
    return `

${Array.from(t.children).filter((o) => o.tagName.toLowerCase() === "li").map((o) => `- ${Array.from(o.childNodes).map((l) => f(l, n)).join("").trim()}`).join(`
`)}

`;
  if (r === "ol")
    return `

${Array.from(t.children).filter((o) => o.tagName.toLowerCase() === "li").map((o, c) => {
      const l = Array.from(o.childNodes).map((s) => f(s, n)).join("").trim();
      return `${c + 1}. ${l}`;
    }).join(`
`)}

`;
  if (r === "table") {
    const e = Array.from(t.querySelectorAll("tr"));
    if (!e.length) return "";
    let o = `

`;
    return e.forEach((c, l) => {
      const s = Array.from(c.querySelectorAll("th, td")).map((d) => d.textContent?.trim().replace(/\|/g, "\\|") || "");
      s.length && (o += `| ${s.join(" | ")} |
`, l === 0 && (o += `| ${s.map(() => "---").join(" | ")} |
`));
    }), o + `
`;
  }
  return r === "hr" ? `

---

` : r === "br" ? `
` : Array.from(t.childNodes).map((e) => f(e, n)).join("");
}
function f(t, n) {
  return t.nodeType === 3 ? t.textContent || "" : t.nodeType === 1 ? O(t, n) : "";
}
function L(t, n) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const e = new DOMParser().parseFromString(N(t), "text/html");
    return Array.from(e.body.childNodes).map((c) => f(c, n)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return N(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (r, e) => `

> ${e.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (r, e, o) => `

${"#".repeat(Number(e))} ${o.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function D(t, n = "article", r = [], e = "") {
  const o = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), c = [
    "---",
    `title: "${(t.title || "未命名网页").replace(/"/g, '\\"')}"`,
    `url: "${t.url || ""}"`,
    `clipped_at: "${o}"`,
    t.author ? `author: "${t.author.replace(/"/g, '\\"')}"` : null,
    t.siteName ? `site_name: "${t.siteName.replace(/"/g, '\\"')}"` : null,
    r.length ? `tags:
${r.map((i) => `  - ${i}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((i) => i !== null).join(`
`), l = [
    `# ${t.title || "未命名网页"}`,
    "",
    `> 原文链接: [${t.url}](${t.url})`,
    t.author ? `> 作者: ${t.author}` : null,
    `> 剪藏时间: ${o.slice(0, 19).replace("T", " ")}`,
    ""
  ].filter((i) => i !== null).join(`
`), s = e.trim() ? `
### 📝 我的笔记与标注

${e.trim()}

---
` : "";
  let d = "";
  if (n === "bookmark")
    d = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (n === "selection")
    d = `
### 摘录内容

${t.selectedHtml ? L(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let i = t.articleHtml ? L(t.articleHtml, t.url) : "";
    i.trim() || (i = t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), d = `
${i}
`;
  }
  return `${c}
${l}${s}${d}`;
}
let a = {
  title: "网页剪藏",
  url: "",
  timestamp: (/* @__PURE__ */ new Date()).toISOString()
}, C = "article", E = !1;
const b = document.getElementById("clip-title"), R = document.getElementById("clip-folder"), k = document.getElementById("clip-tags"), j = document.getElementById("clip-notes"), $ = document.getElementById("preview-content"), S = document.getElementById("toggle-preview-btn"), g = document.getElementById("connection-status"), h = g?.querySelector(".text"), v = document.getElementById("message-bar"), y = document.getElementById("save-btn"), z = document.getElementById("download-btn"), G = document.getElementById("copy-btn"), B = document.querySelectorAll(".tab-btn");
function w(t, n = "success") {
  v && (v.textContent = t, v.className = `message-bar ${n}`, setTimeout(() => {
    v && (v.className = "message-bar");
  }, 4e3));
}
function m() {
  const t = (k?.value || "").split(/[,，\s]+/).map((e) => e.trim()).filter(Boolean), n = j?.value || "", r = D(
    {
      ...a,
      title: b?.value || a.title
    },
    C,
    t,
    n
  );
  return $ && ($.textContent = r), r;
}
function T(t) {
  C = t, B.forEach((n) => {
    n.dataset.mode === t ? n.classList.add("active") : n.classList.remove("active");
  }), m();
}
B.forEach((t) => {
  t.addEventListener("click", () => {
    const n = t.dataset.mode;
    n && T(n);
  });
});
b?.addEventListener("input", m);
k?.addEventListener("input", m);
j?.addEventListener("input", m);
S?.addEventListener("click", () => {
  if (!$ || !S) return;
  $.classList.contains("hidden") ? ($.classList.remove("hidden"), S.classList.add("open")) : ($.classList.add("hidden"), S.classList.remove("open"));
});
G?.addEventListener("click", async () => {
  const t = m();
  await V(t) ? w("已复制 Markdown 内容至剪贴板", "success") : w("复制失败", "error");
});
z?.addEventListener("click", () => {
  const t = m(), r = (b?.value || a.title || "clip").replace(/[\\/:*?"<>|]/g, "-").trim();
  P(`${r}.md`, t), w("已开始下载 Markdown 文件", "success");
});
y?.addEventListener("click", async () => {
  if (!y) return;
  const t = m(), n = (k?.value || "").split(/[,，\s]+/).map((r) => r.trim()).filter(Boolean);
  y.disabled = !0, y.textContent = "保存中...";
  try {
    const r = await q({
      title: b?.value || a.title,
      url: a.url,
      markdown: t,
      tags: n,
      folder: R?.value || "Clippings",
      description: a.description,
      author: a.author,
      mode: C
    });
    if (r.ok && r.success)
      w(`✅ 保存成功: ${r.relativePath || r.filename || ""}`, "success");
    else {
      const e = r.message || r.error || "保存失败，请检查桌面端状态";
      w(`❌ ${e}`, "error");
    }
  } catch (r) {
    w(`保存失败: ${String(r)}`, "error");
  } finally {
    y.disabled = !1, y.textContent = "保存到 Vessel";
  }
});
async function F() {
  let t = null;
  try {
    if (typeof chrome < "u" && chrome.tabs?.query) {
      const r = (await chrome.tabs.query({ active: !0, currentWindow: !0 }).catch(() => []))[0];
      if (r && r.id && r.url && /^https?:\/\//i.test(r.url)) {
        try {
          const e = await chrome.tabs.sendMessage(r.id, { type: "GET_PAGE_DATA" }).catch(() => null);
          e && (e.articleHtml || e.selectedText || e.url) && (t = e);
        } catch {
        }
        if (!t && chrome.scripting?.executeScript)
          try {
            const e = await chrome.scripting.executeScript({
              target: { tabId: r.id },
              func: () => {
                const o = window.getSelection(), c = o ? o.toString().trim() : "";
                let l = "";
                if (o && o.rangeCount > 0 && !o.isCollapsed) {
                  const p = document.createElement("div");
                  p.appendChild(o.getRangeAt(0).cloneContents()), l = p.innerHTML;
                }
                const s = [
                  "#js_content",
                  ".Post-RichText",
                  ".RichContent-inner",
                  "#content_views",
                  ".article_content",
                  ".article-viewer",
                  ".markdown-body",
                  ".article-holder",
                  ".article-content",
                  "article",
                  "main",
                  "[role='main']",
                  ".post-content",
                  ".article-content",
                  ".entry-content",
                  "#article-root",
                  "#content",
                  ".article",
                  ".post_body",
                  ".post-body"
                ];
                let d = "";
                for (const p of s) {
                  const u = document.querySelector(p);
                  if (u && (u.innerText || u.textContent || "").trim().length > 20) {
                    d = u.innerHTML;
                    break;
                  }
                }
                if (!d) {
                  const p = document.body || document.documentElement;
                  if (p) {
                    const u = p.cloneNode(!0);
                    ["script", "style", "noscript", "iframe", "nav", "header", "footer", "aside", ".sidebar", ".comments", ".ad"].forEach((x) => {
                      u.querySelectorAll(x).forEach((I) => I.remove());
                    }), d = u.innerHTML;
                  }
                }
                const i = (p) => {
                  for (const u of p) {
                    const A = document.querySelector(`meta[name='${u}'], meta[property='${u}']`);
                    if (A) {
                      const x = A.getAttribute("content");
                      if (x) return x.trim();
                    }
                  }
                  return "";
                };
                return {
                  title: document.title || "未命名网页",
                  url: window.location.href,
                  description: i(["description", "og:description", "twitter:description"]),
                  author: i(["author", "article:author", "twitter:creator"]),
                  siteName: i(["og:site_name", "application-name"]) || window.location.hostname,
                  selectedText: c,
                  selectedHtml: l,
                  articleHtml: d,
                  timestamp: (/* @__PURE__ */ new Date()).toISOString()
                };
              }
            });
            e && e[0]?.result && (t = e[0].result);
          } catch (e) {
            console.warn("executeScript fallback error:", e);
          }
      }
    }
  } catch (n) {
    console.warn("Chrome tab query error:", n);
  }
  if (!t || !t.articleHtml)
    try {
      const n = await fetch("http://127.0.0.1:35678/api/active-page");
      if (n.ok) {
        const r = await n.json(), e = r.data || r;
        e && e.url && (t = {
          title: e.title || t?.title || "未命名网页",
          url: e.url || t?.url || "",
          description: e.description || t?.description || "",
          author: e.author || t?.author || "",
          siteName: e.siteName || t?.siteName || "",
          favicon: e.favicon || t?.favicon || "",
          articleHtml: e.articleHtml || t?.articleHtml || "",
          selectedText: e.selectedText || t?.selectedText || "",
          selectedHtml: e.selectedHtml || t?.selectedHtml || "",
          timestamp: e.timestamp || (/* @__PURE__ */ new Date()).toISOString()
        });
      }
    } catch (n) {
      console.warn("Vessel bridge fetch error:", n);
    }
  t && (a = t, b && a.title && (b.value = a.title), a.selectedText && a.selectedText.trim() ? T("selection") : T("article")), m();
}
async function Z() {
  m();
  try {
    const t = await _();
    if (t && t.ok) {
      E = !0, g && (g.className = "status-badge connected");
      const n = t.workspace?.name ? `已连接: ${t.workspace.name}` : "已连接 Vessel";
      h && (h.textContent = n);
    } else
      E = !1, g && (g.className = "status-badge disconnected"), h && (h.textContent = "未连接桌面端");
  } catch (t) {
    console.error("Vessel check error:", t), E = !1, g && (g.className = "status-badge disconnected"), h && (h.textContent = "未连接桌面端");
  }
  await F();
}
Z();
