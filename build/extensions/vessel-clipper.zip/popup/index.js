const I = "http://127.0.0.1:35678";
async function q() {
  try {
    const t = new AbortController(), n = setTimeout(() => t.abort(), 1200), r = await fetch(`${I}/api/status`, {
      method: "GET",
      signal: t.signal
    });
    return clearTimeout(n), r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}
async function P(t) {
  try {
    return await (await fetch(`${I}/api/clip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t)
    })).json();
  } catch (n) {
    return {
      ok: !1,
      error: `无法连接到 Vessel 桌面端: ${String(n)}`
    };
  }
}
function O(t, n) {
  const r = new Blob([n], { type: "text/markdown;charset=utf-8" }), e = URL.createObjectURL(r);
  if (typeof chrome < "u" && chrome.downloads?.download)
    chrome.downloads.download({
      url: e,
      filename: t,
      saveAs: !1
    });
  else {
    const o = document.createElement("a");
    o.href = e, o.download = t, document.body.appendChild(o), o.click(), document.body.removeChild(o);
  }
}
async function V(t) {
  try {
    if (navigator.clipboard)
      return await navigator.clipboard.writeText(t), !0;
  } catch {
  }
  return !1;
}
function L(t, n) {
  try {
    return new URL(t, n).href;
  } catch {
    return t;
  }
}
function j(t) {
  return t.replace(/<script\b[\s\S]*?<\/script>/gi, "").replace(/<style\b[\s\S]*?<\/style>/gi, "").replace(/<noscript\b[\s\S]*?<\/noscript>/gi, "").replace(/<iframe\b[\s\S]*?<\/iframe>/gi, "").replace(/<svg\b[\s\S]*?<\/svg>/gi, "").replace(/<!--[\s\S]*?-->/g, "");
}
function D(t, n) {
  const r = t.tagName.toLowerCase();
  if (["script", "style", "noscript", "iframe", "svg", "nav", "footer"].includes(r))
    return "";
  if (/^h[1-6]$/.test(r)) {
    const e = parseInt(r[1], 10), o = t.textContent?.trim() || "";
    return `

${"#".repeat(e)} ${o}

`;
  }
  if (r === "p") {
    const e = Array.from(t.childNodes).map((o) => g(o, n)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (["div", "section", "article", "figure", "header", "main", "aside", "details", "summary"].includes(r)) {
    const e = Array.from(t.childNodes).map((o) => g(o, n)).join("").trim();
    return e ? `

${e}

` : "";
  }
  if (r === "strong" || r === "b") {
    const e = t.textContent?.trim() || "";
    return e ? `**${e}**` : "";
  }
  if (r === "em" || r === "i") {
    const e = t.textContent?.trim() || "";
    return e ? `*${e}*` : "";
  }
  if (r === "del" || r === "s" || r === "strike") {
    const e = t.textContent?.trim() || "";
    return e ? `~~${e}~~` : "";
  }
  if (r === "a") {
    const e = t.getAttribute("href"), o = t.textContent?.trim() || e || "";
    if (!e) return o;
    const c = L(e, n);
    return `[${o}](${c})`;
  }
  if (r === "img") {
    const e = t.getAttribute("src") || t.getAttribute("data-src") || t.getAttribute("data-original-src") || t.getAttribute("data-actualsrc") || t.getAttribute("data-lazy-src");
    if (!e) return "";
    const o = t.getAttribute("alt") || "image", c = L(e, n);
    return `

![${o}](${c})

`;
  }
  if (r === "pre") {
    const e = t.querySelector("code"), o = (e ? e.textContent : t.textContent) || "";
    let c = "";
    const s = (e?.getAttribute("class") || t.getAttribute("class") || "").match(/language-([a-zA-Z0-9_-]+)/);
    return s && (c = s[1]), `

\`\`\`${c}
${o.replace(/^\n+|\n+$/g, "")}
\`\`\`

`;
  }
  if (r === "code")
    return `\`${t.textContent || ""}\``;
  if (r === "blockquote")
    return `

${Array.from(t.childNodes).map((o) => g(o, n)).join("").trim().split(`
`).map((o) => `> ${o}`).join(`
`)}

`;
  if (r === "ul")
    return `

${Array.from(t.children).filter((o) => o.tagName.toLowerCase() === "li").map((o) => `- ${Array.from(o.childNodes).map((d) => g(d, n)).join("").trim()}`).join(`
`)}

`;
  if (r === "ol")
    return `

${Array.from(t.children).filter((o) => o.tagName.toLowerCase() === "li").map((o, c) => {
      const d = Array.from(o.childNodes).map((s) => g(s, n)).join("").trim();
      return `${c + 1}. ${d}`;
    }).join(`
`)}

`;
  if (r === "table") {
    const e = Array.from(t.querySelectorAll("tr"));
    if (!e.length) return "";
    let o = `

`;
    return e.forEach((c, d) => {
      const s = Array.from(c.querySelectorAll("th, td")).map((m) => m.textContent?.trim().replace(/\|/g, "\\|") || "");
      s.length && (o += `| ${s.join(" | ")} |
`, d === 0 && (o += `| ${s.map(() => "---").join(" | ")} |
`));
    }), o + `
`;
  }
  return r === "hr" ? `

---

` : r === "br" ? `
` : Array.from(t.childNodes).map((e) => g(e, n)).join("");
}
function g(t, n) {
  return t.nodeType === 3 ? t.textContent || "" : t.nodeType === 1 ? D(t, n) : "";
}
function B(t, n) {
  if (!t) return "";
  if (typeof DOMParser < "u") {
    const e = new DOMParser().parseFromString(j(t), "text/html");
    return Array.from(e.body.childNodes).map((c) => g(c, n)).join("").replace(/\n{3,}/g, `

`).trim();
  }
  return j(t).replace(/<pre[^>]*><code[^>]*class="[^"]*language-([a-zA-Z0-9_-]+)[^"]*"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```$1\n$2\n```\n\n").replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "\n\n```\n$1\n```\n\n").replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (r, e) => `

> ${e.trim().replace(/\n/g, `
> `)}

`).replace(/<li[^>]*>(.*?)<\/li>/gi, `
- $1`).replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (r, e, o) => `

${"#".repeat(Number(e))} ${o.trim()}

`).replace(/<p[^>]*>(.*?)<\/p>/gi, `

$1

`).replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*").replace(/<del[^>]*>(.*?)<\/del>/gi, "~~$1~~").replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, `
`).replace(/<hr\s*\/?>/gi, `

---

`).replace(/<[^>]+>/g, "").replace(/\n{3,}/g, `

`).trim();
}
function R(t, n = "article", r = [], e = "") {
  const o = t.timestamp || (/* @__PURE__ */ new Date()).toISOString(), c = [
    "---",
    `title: "${(t.title || "未命名网页").replace(/"/g, '\\"')}"`,
    `url: "${t.url || ""}"`,
    `clipped_at: "${o}"`,
    t.author ? `author: "${t.author.replace(/"/g, '\\"')}"` : null,
    t.siteName ? `site_name: "${t.siteName.replace(/"/g, '\\"')}"` : null,
    r.length ? `tags:
${r.map((i) => `  - ${i}`).join(`
`)}` : "tags: [剪藏]",
    "---",
    ""
  ].filter((i) => i !== null).join(`
`), d = [
    `# ${t.title || "未命名网页"}`,
    "",
    `> 原文链接: [${t.url}](${t.url})`,
    t.author ? `> 作者: ${t.author}` : null,
    `> 剪藏时间: ${o.slice(0, 19).replace("T", " ")}`,
    ""
  ].filter((i) => i !== null).join(`
`), s = e.trim() ? `
### 📝 我的笔记与标注

${e.trim()}

---
` : "";
  let m = "";
  if (n === "bookmark")
    m = t.description ? `
### 简介

${t.description}
` : `
### 网址书签已收录

已成功保存网址至 Vessel 工作区。
`;
  else if (n === "selection")
    m = `
### 摘录内容

${t.selectedHtml ? B(t.selectedHtml, t.url) : t.selectedText || ""}
`;
  else {
    let i = t.articleHtml ? B(t.articleHtml, t.url) : "";
    i.trim() || (i = t.articleText ? t.articleText : t.selectedText ? `### 摘录内容

${t.selectedText}` : t.description ? `### 页面简介

${t.description}` : "> ⚠️ 未能自动提取到正文内容。若页面使用特殊动态渲染，建议在网页上选中文本后使用【✂️ 选中文字】模式剪藏。"), m = `
${i}
`;
  }
  return `${c}
${d}${s}${m}`;
}
let l = {
  title: "网页剪藏",
  url: "",
  timestamp: (/* @__PURE__ */ new Date()).toISOString()
}, M = "article", k = !1;
const x = document.getElementById("clip-title"), z = document.getElementById("clip-folder"), N = document.getElementById("clip-tags"), H = document.getElementById("clip-notes"), w = document.getElementById("preview-content"), S = document.getElementById("toggle-preview-btn"), h = document.getElementById("connection-status"), y = h?.querySelector(".text"), v = document.getElementById("message-bar"), $ = document.getElementById("save-btn"), G = document.getElementById("download-btn"), F = document.getElementById("copy-btn"), _ = document.querySelectorAll(".tab-btn");
function b(t, n = "success") {
  v && (v.textContent = t, v.className = `message-bar ${n}`, setTimeout(() => {
    v && (v.className = "message-bar");
  }, 4e3));
}
function p() {
  const t = (N?.value || "").split(/[,，\s]+/).map((e) => e.trim()).filter(Boolean), n = H?.value || "", r = R(
    {
      ...l,
      title: x?.value || l.title
    },
    M,
    t,
    n
  );
  return w && (w.textContent = r), r;
}
function C(t) {
  M = t, _.forEach((n) => {
    n.dataset.mode === t ? n.classList.add("active") : n.classList.remove("active");
  }), p();
}
_.forEach((t) => {
  t.addEventListener("click", () => {
    const n = t.dataset.mode;
    n && C(n);
  });
});
x?.addEventListener("input", p);
N?.addEventListener("input", p);
H?.addEventListener("input", p);
S?.addEventListener("click", () => {
  if (!w || !S) return;
  w.classList.contains("hidden") ? (w.classList.remove("hidden"), S.classList.add("open")) : (w.classList.add("hidden"), S.classList.remove("open"));
});
F?.addEventListener("click", async () => {
  const t = p();
  await V(t) ? b("已复制 Markdown 内容至剪贴板", "success") : b("复制失败", "error");
});
G?.addEventListener("click", () => {
  const t = p(), r = (x?.value || l.title || "clip").replace(/[\\/:*?"<>|]/g, "-").trim();
  O(`${r}.md`, t), b("已开始下载 Markdown 文件", "success");
});
$?.addEventListener("click", async () => {
  if (!$) return;
  const t = p(), n = (N?.value || "").split(/[,，\s]+/).map((r) => r.trim()).filter(Boolean);
  $.disabled = !0, $.textContent = "保存中...";
  try {
    const r = await P({
      title: x?.value || l.title,
      url: l.url,
      markdown: t,
      tags: n,
      folder: z?.value || "Clippings",
      description: l.description,
      author: l.author,
      mode: M
    });
    if (r.ok && r.success)
      b(`✅ 保存成功: ${r.relativePath || r.filename || ""}`, "success");
    else {
      const e = r.message || r.error || "保存失败，请检查桌面端状态";
      b(`❌ ${e}`, "error");
    }
  } catch (r) {
    b(`保存失败: ${String(r)}`, "error");
  } finally {
    $.disabled = !1, $.textContent = "保存到 Vessel";
  }
});
async function Z() {
  let t = null;
  try {
    const n = await fetch("http://127.0.0.1:35678/api/active-page");
    if (n.ok) {
      const r = await n.json(), e = r.data || r;
      e && (e.url || e.title) && (t = {
        title: e.title || "未命名网页",
        url: e.url || "",
        description: e.description || "",
        author: e.author || "",
        siteName: e.siteName || "",
        favicon: e.favicon || "",
        articleHtml: e.articleHtml || "",
        articleText: e.articleText || "",
        selectedText: e.selectedText || "",
        selectedHtml: e.selectedHtml || "",
        timestamp: e.timestamp || (/* @__PURE__ */ new Date()).toISOString()
      });
    }
  } catch {
  }
  if (!t || !t.articleHtml && !t.articleText && !t.selectedText)
    try {
      if (typeof chrome < "u" && chrome.tabs?.query) {
        const r = (await chrome.tabs.query({ active: !0, currentWindow: !0 }).catch(() => []))[0];
        if (r && r.id && r.url && /^https?:\/\//i.test(r.url)) {
          try {
            const e = await chrome.tabs.sendMessage(r.id, { type: "GET_PAGE_DATA" }).catch(() => null);
            e && (e.articleHtml || e.articleText || e.selectedText || e.url) && (t = e);
          } catch {
          }
          if (!t && chrome.scripting?.executeScript)
            try {
              const e = await chrome.scripting.executeScript({
                target: { tabId: r.id },
                func: () => {
                  const o = window.getSelection(), c = o ? o.toString().trim() : "";
                  let d = "";
                  if (o && o.rangeCount > 0 && !o.isCollapsed) {
                    const u = document.createElement("div");
                    u.appendChild(o.getRangeAt(0).cloneContents()), d = u.innerHTML;
                  }
                  function s(u) {
                    ["script", "style", "noscript", "iframe", "svg", "nav", "header", "footer", "aside", ".sidebar", ".comments", ".ad"].forEach((f) => {
                      u.querySelectorAll(f).forEach((T) => T.remove());
                    });
                  }
                  const m = [
                    "#js_content",
                    ".Post-RichText",
                    ".RichContent-inner",
                    "#content_views",
                    ".article_content",
                    ".article-viewer",
                    ".markdown-body",
                    ".article-holder",
                    ".article-content",
                    "article",
                    "main",
                    "[role='main']",
                    ".post-content",
                    ".article-content",
                    ".entry-content",
                    "#article-root",
                    "#content",
                    ".article",
                    ".post_body",
                    ".post-body"
                  ];
                  let i = "", A = "";
                  for (const u of m) {
                    const a = document.querySelector(u);
                    if (a && (a.innerText || a.textContent || "").trim().length > 20) {
                      const f = a.cloneNode(!0);
                      s(f), i = f.innerHTML, A = (f.innerText || "").trim();
                      break;
                    }
                  }
                  if (!i) {
                    const u = document.body || document.documentElement;
                    if (u) {
                      const a = u.cloneNode(!0);
                      s(a), i = a.innerHTML, A = (a.innerText || "").trim();
                    }
                  }
                  const E = (u) => {
                    for (const a of u) {
                      const f = document.querySelector(`meta[name='${a}'], meta[property='${a}']`);
                      if (f) {
                        const T = f.getAttribute("content");
                        if (T) return T.trim();
                      }
                    }
                    return "";
                  };
                  return {
                    title: document.title || "未命名网页",
                    url: window.location.href,
                    description: E(["description", "og:description", "twitter:description"]),
                    author: E(["author", "article:author", "twitter:creator"]),
                    siteName: E(["og:site_name", "application-name"]) || window.location.hostname,
                    selectedText: c,
                    selectedHtml: d,
                    articleHtml: i,
                    articleText: A,
                    timestamp: (/* @__PURE__ */ new Date()).toISOString()
                  };
                }
              });
              e && e[0]?.result && (t = e[0].result);
            } catch (e) {
              console.warn("executeScript fallback error:", e);
            }
        }
      }
    } catch (n) {
      console.warn("Chrome tab query error:", n);
    }
  t && (l = t, x && l.title && (x.value = l.title), l.selectedText && l.selectedText.trim() ? C("selection") : C("article")), p();
}
async function J() {
  p();
  try {
    const t = await q();
    if (t && t.ok) {
      k = !0, h && (h.className = "status-badge connected");
      const n = t.workspace?.name ? `已连接: ${t.workspace.name}` : "已连接 Vessel";
      y && (y.textContent = n);
    } else
      k = !1, h && (h.className = "status-badge disconnected"), y && (y.textContent = "未连接桌面端");
  } catch (t) {
    console.error("Vessel check error:", t), k = !1, h && (h.className = "status-badge disconnected"), y && (y.textContent = "未连接桌面端");
  }
  await Z();
}
J();
